<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
G5SERVICES()->load_file(G5SERVICES()->plugin_dir('inc/functions/conditional.php'));
G5SERVICES()->load_file(G5SERVICES()->plugin_dir('inc/functions/helper.php'));
G5SERVICES()->load_file(G5SERVICES()->plugin_dir('inc/functions/template.php'));
