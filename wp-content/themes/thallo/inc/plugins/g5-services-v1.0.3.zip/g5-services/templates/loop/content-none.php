<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<p class="g5services__not-found"><?php esc_html_e('No services were found matching your selection.','g5-services')?></p>