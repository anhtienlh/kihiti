<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<a class="g5services__loop-view-more" href="<?php the_permalink() ?>"><span><?php esc_html_e('Read More','thallo-addons') ?></span><i class="fas fa-arrow-right"></i></a>
