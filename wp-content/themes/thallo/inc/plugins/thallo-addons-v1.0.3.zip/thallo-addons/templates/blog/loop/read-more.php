<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<a class="btn-read-more btn btn-link btn-icon-right btn-dark" href="<?php the_permalink() ?>"><?php esc_html_e('Read More','thallo-addons') ?> <i class="fas fa-arrow-right"></i></a>
