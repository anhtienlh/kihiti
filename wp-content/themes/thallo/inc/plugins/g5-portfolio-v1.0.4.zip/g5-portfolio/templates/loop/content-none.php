<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<p class="g5portfolio__not-found"><?php esc_html_e('No portfolio were found matching your selection.','g5-portfolio')?></p>