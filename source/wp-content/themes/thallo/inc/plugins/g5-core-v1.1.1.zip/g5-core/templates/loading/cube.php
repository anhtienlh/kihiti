<?php
/**
 * The template for displaying cube.php
 */
?>
<div class="sk-rotating-plane"></div>
