<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @var $job_title
 */
?>
<div class="g5staff__loop-job-title">
	<?php echo esc_html($job_title)?>
</div>
