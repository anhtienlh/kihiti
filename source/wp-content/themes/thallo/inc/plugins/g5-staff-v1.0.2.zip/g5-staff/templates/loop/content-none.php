<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<p class="g5staff__not-found"><?php esc_html_e('No staff were found matching your selection.','g5-staff')?></p>