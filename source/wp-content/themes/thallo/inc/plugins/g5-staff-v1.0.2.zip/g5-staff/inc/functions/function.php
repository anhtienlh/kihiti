<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
G5STAFF()->load_file(G5STAFF()->plugin_dir('inc/functions/conditional.php'));
G5STAFF()->load_file(G5STAFF()->plugin_dir('inc/functions/helper.php'));
G5STAFF()->load_file(G5STAFF()->plugin_dir('inc/functions/template.php'));
