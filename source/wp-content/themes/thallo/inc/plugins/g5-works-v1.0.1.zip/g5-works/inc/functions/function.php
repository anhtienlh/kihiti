<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
G5WORKS()->load_file(G5WORKS()->plugin_dir('inc/functions/conditional.php'));
G5WORKS()->load_file(G5WORKS()->plugin_dir('inc/functions/helper.php'));
G5WORKS()->load_file(G5WORKS()->plugin_dir('inc/functions/template.php'));
