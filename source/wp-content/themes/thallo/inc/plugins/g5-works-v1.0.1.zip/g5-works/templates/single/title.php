<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<h1 class="g5works__single-title"><?php the_title() ?></h1>
