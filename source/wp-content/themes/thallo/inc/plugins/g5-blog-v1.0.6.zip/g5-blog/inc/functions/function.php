<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
G5BLOG()->load_file(G5BLOG()->plugin_dir('inc/functions/helper.php'));
G5BLOG()->load_file(G5BLOG()->plugin_dir('inc/functions/template.php'));
G5BLOG()->load_file(G5BLOG()->plugin_dir('inc/functions/template-hooks.php'));